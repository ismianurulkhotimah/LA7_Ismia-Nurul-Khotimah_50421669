/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rpl2_pert1;

/**
 *
 * @author mia
 */
public class Component implements Printable{
    @Override
    public void print() {
        System.out.println("Ismia Nurul Khotimah");
    }
}
