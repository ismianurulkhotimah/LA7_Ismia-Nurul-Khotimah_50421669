package rpl2_pert2_50421669;

public class RPL2_Pert2_50421669 {

    public static void main(String[] args) {
        Mahasiswa mahasiswa = new Mahasiswa();
        
        mahasiswa.setName("Ismia Nurul Khotimah");
        mahasiswa.setNpm("50421669");
        mahasiswa.setClassNumber("4IA06");
        mahasiswa.setBirthYear(2002);
        mahasiswa.setAlamat("Jakarta Timur");
        
        System.out.println(mahasiswa.toString());
    }
    
}
